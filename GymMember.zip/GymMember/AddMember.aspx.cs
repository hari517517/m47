﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GymMember
{
    public partial class AddMember : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            rvSdate.ValueToCompare = DateTime.Now.ToString("dd/MM/yyyy");
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("INSERT INTO GymMember_B (Member_Code, Member_Name, EmailID, Phone_No,MemSD, Mem_Duration) VALUES(@Member_Code, @Member_Name, @EmailID, @Phone_No, @MemSD,@Mem_Duration)", con);
            cmd.Parameters.AddWithValue("@Member_Code", txtMemCode.Text);

          

            cmd.Parameters.AddWithValue("@Member_Name", txtMemName.Text);
            cmd.Parameters.AddWithValue("@EmailID", txtemail.Text);
            cmd.Parameters.AddWithValue("@Phone_No", txtPhoneNo.Text);
            cmd.Parameters.AddWithValue("@MemSD", Convert.ToDateTime(txtSDate.Text));
            cmd.Parameters.AddWithValue("@Mem_Duration", dropDur.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('New Student Added Successfully');</script>");
                //Response.Redirect("Home.aspx");
                Server.Transfer("Home.aspx");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('New Student not added');</script>");
            }
        }
    }
}